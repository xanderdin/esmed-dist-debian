DO NOT CHANGE OR REMOVE esmed_plugin.pyc FILE IN THIS DIRECTORY!!!

It is required for correct setup.py functioning when installing
or uninstalling Twisted plugin (twisted/plugins/esmed_plugin.py).